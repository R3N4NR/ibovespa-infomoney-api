from flask import Flask, jsonify
from flask_cors import CORS
import asyncio
import threading

from scrapper.scrape_html import scrape_html
from scrapper.data_parser import extract_table_data
from db.insert_data import insert_data_from_dict
from db.connection import get_pool
from ws.server import send_to_all_clients

from main import start_scraper  # importa a função que roda o scraping automático

app = Flask(__name__)
CORS(app)

@app.route('/scrape', methods=['GET'])
def scrape_route():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    html = scrape_html()
    data = extract_table_data(html)
    loop.run_until_complete(insert_data_from_dict(data))
    loop.run_until_complete(send_to_all_clients(data))
    return jsonify({"status": "ok", "message": "Dados coletados, inseridos e enviados"}), 200

@app.route('/stocks', methods=['GET'])
def get_stocks():
    async def fetch_data():
        pool = await get_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch("SELECT * FROM stocks")
        await pool.close()
        return [dict(row) for row in rows]

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    stocks_data = loop.run_until_complete(fetch_data())
    return jsonify(stocks_data), 200

if __name__ == "__main__":
    # inicia o scraper automático em thread separada
    scraper_thread = threading.Thread(target=start_scraper, daemon=True)
    scraper_thread.start()

    # inicia o servidor Flask
    app.run(port=5000)
