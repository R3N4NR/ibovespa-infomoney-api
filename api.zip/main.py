import asyncio
from scrapper.scrape_html import scrape_html
from scrapper.save_html import save_html_to_file
from scrapper.data_parser import extract_table_data
from db.insert_data import insert_data_from_dict
from db.schema import create_table

async def run_once():
    html = scrape_html()
    save_html_to_file(html)
    data = extract_table_data(html)
    await insert_data_from_dict(data)

async def main_loop(interval=600):
    await create_table()
    while True:
        print("Executando scraping e atualização de dados...")
        try:
            await run_once()
        except Exception as e:
            print(f"Erro durante execução: {e}")
        print(f"Aguardando {interval} segundos para a próxima execução...\n")
        await asyncio.sleep(interval)

if __name__ == "__main__":
    asyncio.run(main_loop())
