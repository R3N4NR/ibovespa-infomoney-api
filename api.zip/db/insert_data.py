from db.connection import get_pool
from datetime import datetime

def parse_number(value):
    if value is None:
        return None
    return float(value.replace('.', '').replace(',', '.').replace('%', ''))

async def insert_data_from_dict(data):
    pool = await get_pool()
    async with pool.acquire() as conn:
        for date, values in data.items():
            referencia = datetime.strptime(date, "%Y-%m-%d").date()
            for tipo in ['high_values', 'low_values']:
                for item in values.get(tipo, []):
                    await conn.execute("""
                        INSERT INTO stocks (ativo, ultimo, variacao, val_min, val_max, data)
                        VALUES ($1, $2, $3, $4, $5, $6)
                        ON CONFLICT (ativo)
                        DO UPDATE SET
                            ultimo = EXCLUDED.ultimo,
                            variacao = EXCLUDED.variacao,
                            val_min = EXCLUDED.val_min,
                            val_max = EXCLUDED.val_max,
                            data = EXCLUDED.data
                    """,
                    item.get("Ativo"),
                    parse_number(item.get("Último (R$)")),
                    parse_number(item.get("Var. Dia (%)")),
                    parse_number(item.get("Val. Min (R$)")),
                    parse_number(item.get("Val. Máx (R$)")),
                    item.get("Data")
                    
                    )
    await pool.close()
    print("Dados inseridos/atualizados no banco.")
