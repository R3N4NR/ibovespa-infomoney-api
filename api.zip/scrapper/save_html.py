import os

def save_html_to_file(html, filename="data/pagina.html"):
    """
    Salva o HTML bruto da página em um arquivo local.

    Parâmetros:
    - html (str): Conteúdo HTML capturado via Selenium.
    - filename (str): Caminho onde o arquivo será salvo. Padrão é 'data/pagina.html'.
    """
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    with open(filename, "w", encoding="utf-8") as f:
        f.write(html)
